# Changelog - Guess the Number Game

All notable changes to this project will be documented in this file.

## [v1.0.0] - 2026-08-03
### Added
- Main game function wrapper `run_guessing_game()`.
- Outer replay loop with clean exit controls (LO1, LO2).
### Audited
- Full loop exit path review; confirmed zero infinite loop paths (LO4).

## [v0.4.0] - 2026-08-03
### Added
- Nested `for` loop victory celebration banner triggered upon correct guess (LO3).

## [v0.3.0] - 2026-08-03
### Added
- Defensive guardrails using `.isdigit()` and boundary checks (1–100) (LO4).
- `continue` statements to prevent turn penalties on invalid input (LO2).

## [v0.2.0] - 2026-08-03
### Added
- `random.randint` target generation.
- Conditional directional hints ("Too LOW", "Too HIGH") and early `break` on victory (LO1, LO2).

## [v0.1.0] - 2026-08-03
### Added
- Basic `while` loop counting structure capped at 7 attempts (LO1).
