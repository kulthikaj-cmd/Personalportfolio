# **AI Ethics, Explainability, Responsibility Explained**

[https://gemini.google.com/app/8f528f2c331b7d6e](https://gemini.google.com/app/8f528f2c331b7d6e)

*User prompt: as a python novice, please respond with ai ethics, explainable ai, and responsible ai in mind*

Response: Welcome to the world of Python and AI\! Starting your journey by thinking about **Ethics**, **Explainability**, and **Responsibility** puts you way ahead of the curve. Many developers focus purely on making models work before asking if they *should* work that way.

Here is a simple breakdown of what these three pillars mean, why they matter, and how they apply when writing Python code.

## **1\. AI Ethics: *The "Should We?" Question***

**AI Ethics** is about the moral principles guiding how AI systems are built and used. Just because Python lets you build something in 10 lines of code doesn't mean it’s safe or fair to deploy.

> * **Fairness & Bias:** AI models learn from data. If historical data contains human biases (e.g., gender or racial discrimination in hiring data), your Python script will learn and amplify those biases.  
> * **Privacy:** Respecting user data. If you load user data into a Python library (pandas), are you handling sensitive information safely?

💡 **Python Novice Takeaway:** Your model is only as fair as your dataset. "Garbage in, garbage out" applies to moral garbage, too.

## **2\. Explainable AI (XAI): *The "Why Did It Do That?" Question***

Complex AI models (like deep neural networks) are often called **"black boxes."** You feed data in, and a prediction pops out—but nobody really knows *why* the computer made that specific choice.

**Explainable AI (XAI)** refers to the techniques and tools used so humans can understand, trust, and audit the predictions made by machine learning models.

> * **Interpretable Models:** Simple models in Python, like a basic Decision Tree (from sklearn.tree import DecisionTreeClassifier), are easy to visualize and explain step-by-step.  
> * **XAI Libraries:** When using complex models, Python developers use specialized libraries like **SHAP** or **LIME** to highlight which factors influenced a model's decision the most.

`# Conceptual Example: Interpretable vs. Black Box`  
`# Simple Decision Tree -> Easy to explain`  
`from sklearn.tree import DecisionTreeClassifier`

`model = DecisionTreeClassifier()`  
`# You can plot and literally read the rules this tree learned!`

💡 **Python Novice Takeaway:** If a loan application model denies someone a loan, XAI allows you to explain *which specific variables* led to that outcome instead of saying, "The computer said no."

## **3\. Responsible AI (RAI): *The "How Do We Keep It Safe?" Framework***

If Ethics is the *philosophy* and Explainability is the *tool*, **Responsible AI** is the overall **action plan**. It is the practical framework companies and developers use to make sure AI is safe, secure, accountable, and reliable throughout its entire lifecycle.

Key pillars of Responsible AI include:

> * **Accountability:** Who is responsible if an automated script makes a mistake?  
> * **Safety & Security:** Ensuring your Python code isn't vulnerable to manipulation or bad data inputs.  
> * **Documentation:** Creating "Model Cards" (like a nutrition label for your AI model) that detail how it was trained and what its limitations are.

## **Quick Summary**

| Topic | Core Question | Python Connection |
| :---- | :---- | :---- |
| **AI Ethics** | *Should* we build/use this? | Cleaning and auditing your datasets in pandas to prevent bias. |
| **Explainable AI (XAI)** | *How* did the model make this choice? | Using tools like shap, lime, or simple scikit-learn visualizations. |
| **Responsible AI (RAI)** | *How* do we manage this safely long-term? | Code testing, model monitoring, privacy checks, and clear documentation. |

Are you currently working on a specific Python project or dataset where you'd like to try applying these concepts?

---

*User prompt: Based on the Week 3 curriculum, which focuses on Python Control Flow using for and while loops, loop control statements (break and continue), nested loops, and debugging loop logic, here is a comprehensive breakdown of the Learning Outcomes, Trait Assessments, and a structured Grading Rubric tailored for the Week 3 Mini-Project (such as a Countdown & Guessing Game, Multiplication Table Generator, or other loop-based interactive applications). The learning outcomes are directly aligned with the Week 3 learning outcomes, laboratory activities, and trait assessments in the curriculum. 1\. Week 3 Mini-Project Learning Outcomes (LOs) By completing this mini-project, students will be able to: LO1 (Loop Construction & Iteration): Correctly implement for and while loops to automate repetitive tasks, iterate over ranges or sequences, and perform condition-based repetition. LO2 (Loop Control & Decision Making): Apply break and continue statements appropriately to control loop execution, terminate processes early, or skip unnecessary iterations while maintaining correct program logic. LO3 (Nested Loop Implementation): Design and implement nested loops to solve multi-level iterative problems such as generating multiplication tables, pattern printing, or grid-based outputs. LO4 (Algorithmic Problem Solving & Debugging): Analyze and resolve common loop-related issues—including incorrect loop conditions, improper range definitions, and infinite loops—through systematic debugging and logical reasoning. LO5 (Process Documentation & Reflection): Document the development process by recording program iterations, AI prompt history (if applicable), testing results, debugging steps, and reflections on improvements made throughout the project. 2\. Trait Assessments The project also evaluates broader computational thinking and professional programming habits: Loop Logic & Technical Accuracy: Demonstrates correct implementation of iteration structures, proper loop termination, and effective use of loop control statements while avoiding logical errors such as infinite loops. Algorithmic Thinking & Program Design: Shows the ability to organize repetitive processes into efficient algorithms using appropriate loop structures, resulting in readable, maintainable, and user-friendly code. Reflective Development Process: Demonstrates responsibility for the software development process by documenting coding decisions, debugging activities, AI-assisted development (where applicable), and lessons learned during implementation. 3\. Grading Rubric Matrix Trait Evaluated Excellent (4) Proficient (3) Developing (2) Insufficient (1–0) Loop Logic & Technical Accuracy Both for and while loops are implemented correctly with appropriate use of break, continue, and proper termination conditions. The program executes flawlessly without logical or runtime errors. Core looping structures function correctly with only minor issues in loop control or edge-case handling. Overall functionality remains reliable. Loop structures are partially functional but contain logical mistakes such as incorrect conditions, improper ranges, or inconsistent loop behavior. Loop implementation is largely incorrect or incomplete. Infinite loops, major logical errors, or failure to use looping structures prevent the program from functioning. Algorithmic Thinking & Program Design The program demonstrates excellent algorithmic organization using efficient loop structures. Nested loops, when required, are implemented correctly, producing clear, readable, and well-structured output. The overall algorithm works well and produces expected results, although code organization or output formatting could be improved. The algorithm solves only part of the problem. Nested loops or loop structures are inefficient, confusing, or inconsistently applied. Little or no evidence of structured algorithmic thinking. The program lacks appropriate looping logic or fails to accomplish the required task. Reflective Development Process The development process is thoroughly documented, including AI prompts, debugging strategies, testing iterations, identified errors, and meaningful reflections on improvements made throughout the project. A project log is provided with clear records of development progress, testing, and basic debugging activities, though reflections could be more detailed. Limited documentation is provided, with minimal explanation of debugging, testing, or development decisions. No development log or reflective documentation is submitted, providing no evidence of the programming or debugging process. Project Idea: Guess the Number Game Description: The computer picks a random number, and the user has to guess it. The program gives hints ("too high," "too low") until the correct number is guessed. Fundamental Concepts: while loop (for repeated guesses), random module, conditional statements, input validation. Real-World Use Cases: Interactive Applications: Games, quizzes. User Feedback Systems: Guiding users through a process.*

Response: This is an exceptionally well-structured curriculum breakdown. The direct alignment between the **Learning Outcomes (LOs)**, the **Trait Assessments**, and the **4-Tier Rubric Matrix** provides students with crystal-clear expectations—especially around process documentation and logical integrity.

To show how the **Guess the Number Game** can hit every single rubric requirement (including **LO1–LO5** and responsible programming principles), here is a complete implementation along with a **Reflective Development Log Template** you can give to students.

## **1\. Complete Project Implementation: "Guess the Number"**

This code incorporates **defensive design** (preventing infinite loops and bad input crashes) and explicit logic feedback, keeping Responsible AI and Explainability principles in mind.

`import random`

`def guess_the_number_game():`  
    `print("=========================================")`  
    `print("   WELCOME TO THE NUMBER GUESSING GAME   ")`  
    `print("=========================================")`  
    `print("Rules: Guess the secret number between 1 and 100.")`  
    `print("You have a maximum of 7 attempts per round.\n")`

    `# OUTE R LOOP: Manages game sessions / Replay (LO1)`  
    `while True:`  
        `secret_number = random.randint(1, 100)`  
        `max_attempts = 7`  
        `attempts_used = 0`  
        `has_won = False`

        `# INNER LOOP: Manages user attempts for the current game (LO1)`  
        `while attempts_used < max_attempts:`  
            `remaining = max_attempts - attempts_used`  
            `user_input = input(f"[Attempt {attempts_used + 1}/{max_attempts}] Enter your guess (1-100): ").strip()`

            `# LO4: Algorithmic Debugging / Guard against invalid input`  
            `if not user_input.isdigit():`  
                `print("⚠️  Invalid input! Please enter a whole number.")`  
                `continue  # LO2: Skip incrementing attempts on bad input`

            `guess = int(user_input)`

            `# LO4: Check boundaries`  
            `if guess < 1 or guess > 100:`  
                `print("⚠️  Out of range! Please stay between 1 and 100.")`  
                `continue  # LO2: Skip to next iteration without penalty`

            `# Valid guess made`  
            `attempts_used += 1`

            `# LO2 & Decision Logic`  
            `if guess == secret_number:`  
                `has_won = True`  
                `print(f"\n🎉 Spot on! You guessed {secret_number} in {attempts_used} attempt(s)!")`  
                  
                `# LO3: NESTED LOOP - Generate a dynamic victory reward banner`  
                `print("\n--- VICTORY CELEBRATION ---")`  
                `for row in range(1, attempts_used + 1):  # Rows proportional to efficiency`  
                    `for star in range(row):`  
                        `print("⭐", end="")`  
                    `print()  # Newline after each row`  
                `print("---------------------------\n")`  
                  
                `break  # LO2: Exit inner guessing loop upon victory`

            `elif guess < secret_number:`  
                `print("💡 Hint: Too LOW! Try a higher number.")`  
            `else:`  
                `print("💡 Hint: Too HIGH! Try a lower number.")`

        `# Game over condition if max attempts reached without guessing`  
        `if not has_won:`  
            `print(f"\n❌ Game Over! You've used all {max_attempts} attempts.")`  
            `print(f"The secret number was: {secret_number}\n")`

        `# LO1 & LO2: Ask user to replay or terminate main loop`  
        `replay = input("Do you want to play again? (yes/no): ").lower().strip()`  
        `if replay not in ['yes', 'y']:`  
            `print("\nThank you for playing! Keep coding responsibly.")`  
            `break  # LO2: Terminate outer replay loop`

`if __name__ == "__main__":`  
    `guess_the_number_game()`

## **2\. How This Solution Maps to Your Week 3 Rubric**

| Trait & Learning Outcome | How the Code Fulfills It |
| :---- | :---- |
| **LO1: Loop Construction** | Uses an outer while True loop for game sessions and an inner while attempts\_used \< max\_attempts for turn logic. |
| **LO2: Loop Control** | Uses continue to bypass attempts on invalid text/out-of-bounds input, and break to exit loops on victory or when quitting. |
| **LO3: Nested Loops** | Uses nested for loops inside the victory condition to print a dynamic star triangle based on player efficiency. |
| **LO4: Debugging & Safety** | Prevents infinite loops by capping attempts (max\_attempts \= 7\) and handles invalid string inputs using .isdigit(). |
| **Explainability (XAI Focus)** | Every hint ("Too HIGH", "Out of range") clearly explains **why** the state changed, giving transparent user feedback. |

## **3\. LO5 Artifact: Reflective Development Log Template**

To ensure students earn **"Excellent (4)"** under the **Reflective Development Process** trait, you can provide this quick submission template:

### **📝 Week 3 Mini-Project Reflective Log**

**Student Name:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Project Choice:** Guess the Number Game

#### **1\. Debugging Log (LO4)**

> * **Bug / Issue Encountered:** *e.g., Typing "ten" crashed the program with a ValueError.*  
> * **Root Cause:** *int() cannot convert string words directly.*  
> * **Fix Implemented:** *Added if not user\_input.isdigit(): and continue to skip invalid turns.*

#### **2\. AI Collaboration & Prompt History (LO5 & Responsible AI)**

> * **AI Tool Used (if applicable):** *e.g., ChatGPT / Claude / Gemini*  
> * **Prompt Used:** *"How do I stop a while loop in Python if a user enters letters instead of numbers?"*  
> * **Reflection on AI Output:** *The AI suggested using a try-except block or .isdigit(). I chose .isdigit() because it was easier to read for our Week 3 topics.*

#### **3\. Personal Reflection**

> * *What was the hardest loop logic to get right, and how did you verify your code was working as expected?*

Would you like me to adapt this mini-project format or code structure for one of the other options, like the **Multiplication Table Generator**?

---

*User prompt: why introduce kanban, wip, and changelog since the beginning of python programming is a good idea for students to use gen ai to grasp teacher materials and make progress rapidly in learning python along with learning\_log.ipynb for prompt and response logging, adjust kanban backlogs according to this outline of the mini project*

Response: Introducing **Kanban**, **WIP (Work In Progress) limits**, a **Changelog**, and a **learning\_log.ipynb** right from day one of learning Python with Gen AI is a brilliant pedagogical strategy.

When beginners use Gen AI, the biggest danger isn't that they won't get code—it's **AI-induced cognitive overwhelm** and **passive code-copying**. AI can spit out a 100-line complete program in 3 seconds, leaving a novice completely lost regarding how or why it works.

By introducing these agile practices early, you transform students from **passive consumers of AI code** into **active directors and auditors of software development**.

## **Why This Framework Supercharges AI-Assisted Learning**

`[ AI Output ] ---> ( WIP Limit Filters ) ---> [ Kanban Task ] ---> ( Changelog + Jupyter Log ) ---> [ True Comprehension ]`

### **1\. Kanban \+ WIP Limits: Defeating AI Overwhelm**

> * **The Problem:** Ask AI "How do I build a guessing game?" and it will give you loops, functions, exception handling, and UI formatting all at once. The student tries to digest everything simultaneously and learns nothing.  
> * **The Solution:** A **WIP limit of 1 or 2 tasks** forces the student to say to the AI: *"Do not build the whole game. Right now, I am only learning LO1: how to make a basic while loop repeat 5 times."*

### **2\. learning\_log.ipynb: Meta-Cognition & Responsible AI**

> * **Prompt/Response Transparency:** Keeping a dedicated Jupyter Notebook for Gen AI prompts makes the student's *thinking process* visible.  
> * **AI Ethics in Action:** It prevents blind copy-pasting. Students must document what they asked, what the AI suggested, and whether the AI's explanation actually made sense to them (fulfilling **LO5**).

### **3\. The Changelog: Intentionality & Debugging**

> * AI love to rewrite entire code blocks, often breaking things that previously worked.  
> * Maintaining a simple **CHANGELOG.md** forces students to track incremental progress. If an AI suggestion breaks their code during **LO4 (Debugging)**, they can look at their changelog to see exactly what changed and roll it back.

## **Week 3 Mini-Project Kanban Backlog**

Here is how you can structure the Kanban backlog specifically for the **Week 3 Mini-Project (Guess the Number Game)**, ensuring students check off **LO1–LO5** systematically using Gen AI.

### **📋 The Kanban Board Structure**

`+-------------------+-------------------+------------------------+-------------------+`  
`|     BACKLOG       |  IN PROGRESS      | AI TESTING & LOGGING   |       DONE        |`  
`|  (To Be Planned)  | (WIP Limit: 1)    | (WIP Limit: 1)         | (Verified Logic)  |`  
`+-------------------+-------------------+------------------------+-------------------+`

### **🏷️ Adjusted Backlog Items (Mapped to LOs)**

| Task ID | Kanban Card Title | Targeted LO | Gen AI Prompting Goal |
| :---- | :---- | :---- | :---- |
| **CARD 1** | **Setup Core Game Loop** | **LO1** | Ask AI to explain a simple while loop that counts from 1 to 7 without any game logic yet. |
| **CARD 2** | **Add User Input & Decision Logic** | **LO1 & LO2** | Prompt AI on how to compare user input with a static secret number using if/elif/else. |
| **CARD 3** | **Implement Defensive Guardrails** | **LO2 & LO4** | Prompt AI: *"How do I use continue and .isdigit() so typing letters won't crash my loop?"* |
| **CARD 4** | **Design Victory Reward Banner** | **LO3** | Ask AI to explain how **nested for loops** print pattern triangles, then implement it in the victory branch. |
| **CARD 5** | **Audit, Refactor & Replay Option** | **LO2 & LO4** | Add the outer replay loop using break. Prompt AI to review code for infinite loop vulnerabilities. |
| **CARD 6** | **Final Process Documentation** | **LO5** | Export learning\_log.ipynb and finalize the project CHANGELOG.md. |

## **Example Artifacts for Students**

To make this concrete, here is how the student's workflow looks in practice for **CARD 3**:

### **1\. learning\_log.ipynb Entry (Prompt & Response Log)**

**Cell 1 (Markdown):**

### **Task: CARD 3 \- Guard against string inputs**

**My Intent:** I want to stop the loop from crashing when a user types "five" instead of 5\.

**Cell 2 (My Prompt to Gen AI):**

*"I have a while loop taking input(). How do I use continue to skip the loop iteration if the input is not a number, without losing an attempt?"*

**Cell 3 (Gen AI Response Summary & Reflection):**

*AI suggested using .isdigit(). If false, print warning and run continue. This skips all code below it and jumps straight back to the while condition\!*

### **2\. CHANGELOG.md Entry**

`## [v0.3.0] - 2026-08-03`  
`### Added`  
``- Input validation using `.isdigit()` and `continue` statement (LO2, LO4).``

`### Fixed`  
`- Fixed bug where typing letters subtracted an attempt from the player.`

Would you like me to draft a template for the **learning\_log.ipynb** notebook that you can distribute directly to your students?

---

*User prompt: execute the kanban backlog*

Response: Here is the step-by-step execution of the Kanban backlog for the **Guess the Number Game**.

We will walk through each Kanban card with a strict **Work In Progress (WIP) limit of 1**, demonstrating how the Python code, the learning\_log.ipynb entries, and the CHANGELOG.md evolve together in real time.

## **🚦 Initial Board State**

`+-----------------------------------------------------------------------------------+`  
`| BACKLOG: [CARD 1] [CARD 2] [CARD 3] [CARD 4] [CARD 5] [CARD 6]                    |`  
`| IN PROGRESS (WIP: 1): None                                                        |`  
`| AI TESTING & LOGGING (WIP: 1): None                                               |`  
`| DONE: None                                                                        |`  
`+-----------------------------------------------------------------------------------+`

## **🏃 Card Execution Walkthrough**

### **📍 Step 1: CARD 1 – Setup Core Game Loop (LO1)**

**Board Move:** Move **\[CARD 1\]** to **IN PROGRESS** → **AI TESTING & LOGGING** → **DONE**

#### **1\. learning\_log.ipynb Entry**

**Intent:** I need a simple loop that runs 7 times to limit the player's attempts before introducing game logic.

**AI Prompt:**

*"How do I make a basic while loop in Python that counts up from 1 to 7 and stops automatically?"*

**AI Explanation & Reflection:**

The AI explained that a while loop checks a condition before every turn. A counter variable (e.g., attempts \= 0\) must be manually incremented inside the loop (attempts \+= 1), or the loop will run forever (infinite loop).

#### **2\. Python Code (Incremental Version 0.1.0)**

`# Version 0.1.0 - Core Loop Setup`  
`attempts = 0`  
`max_attempts = 7`

`while attempts < max_attempts:`  
    `attempts += 1`  
    `print(f"Attempt {attempts} of {max_attempts}")`

`print("Loop finished!")`

#### **3\. CHANGELOG.md Update**

`## [v0.1.0] - Core Loop Initialized`  
`### Added`  
``- Basic `while` loop structure capped at 7 attempts (LO1).``

### **📍 Step 2: CARD 2 – User Input & Decision Logic (LO1 & LO2)**

**Board Move:** Move **\[CARD 2\]** to **IN PROGRESS** → **AI TESTING & LOGGING** → **DONE**

#### **1\. learning\_log.ipynb Entry**

**Intent:** Convert string input into an integer, generate a random target, and give higher/lower feedback.

**AI Prompt:**

*"How do I generate a random number between 1 and 100 in Python and compare a user's guess using if/elif/else?"*

**AI Explanation & Reflection:**

random.randint(1, 100\) picks the secret number. Input from input() is always a string, so I must convert it using int(user\_input) before performing numeric comparisons.

#### **2\. Python Code (Incremental Version 0.2.0)**

`# Version 0.2.0 - Added Input and Comparison Logic`  
`import random`

`secret_number = random.randint(1, 100)`  
`attempts = 0`  
`max_attempts = 7`

`while attempts < max_attempts:`  
    `attempts += 1`  
    `guess = int(input(f"[Attempt {attempts}/{max_attempts}] Guess a number (1-100): "))`

    `if guess == secret_number:`  
        `print("🎉 You guessed it!")`  
        `break  # LO2: Exit loop early on correct guess`  
    `elif guess < secret_number:`  
        `print("💡 Too LOW!")`  
    `else:`  
        `print("💡 Too HIGH!")`

#### **3\. CHANGELOG.md Update**

`## [v0.2.0] - Integrated Input & Hints`  
`### Added`  
``- Random secret number generation using `random.randint` (LO1).``  
``- `if/elif/else` conditional logic for directional feedback.``  
``- `break` statement to exit loop early upon winning (LO2).``

### **📍 Step 3: CARD 3 – Implement Defensive Guardrails (LO2 & LO4)**

**Board Move:** Move **\[CARD 3\]** to **IN PROGRESS** → **AI TESTING & LOGGING** → **DONE**

#### **1\. learning\_log.ipynb Entry**

**Intent:** Prevent the program from crashing if a user types words ("ten") or out-of-bounds numbers ("150").

**AI Prompt:**

*"If a user types letters into input(), Python throws a ValueError. How can I use .isdigit() and continue to ignore bad inputs without wasting an attempt?"*

**AI Explanation & Reflection:**

The .isdigit() method returns True only if all characters are numbers. By placing validation *before* incrementing attempts and calling continue, Python skips the rest of the loop block and restarts at the top without penalty.

#### **2\. Python Code (Incremental Version 0.3.0)**

`# Version 0.3.0 - Defensive Guardrails Added`  
`import random`

`secret_number = random.randint(1, 100)`  
`attempts = 0`  
`max_attempts = 7`

`while attempts < max_attempts:`  
    `user_input = input(f"[Attempt {attempts + 1}/{max_attempts}] Guess a number (1-100): ").strip()`

    `# LO4: Guardrail 1 - Check if input is a valid number`  
    `if not user_input.isdigit():`  
        `print("⚠️ Invalid input! Please enter digits only.")`  
        `continue  # LO2: Skip incrementing attempts`

    `guess = int(user_input)`

    `# LO4: Guardrail 2 - Check valid range`  
    `if guess < 1 or guess > 100:`  
        `print("⚠️ Out of range! Stay between 1 and 100.")`  
        `continue  # LO2: Skip incrementing attempts`

    `# Valid guess made, increment turn`  
    `attempts += 1`

    `if guess == secret_number:`  
        `print(f"🎉 Correct! You won in {attempts} attempt(s)!")`  
        `break`  
    `elif guess < secret_number:`  
        `print("💡 Too LOW!")`  
    `else:`  
        `print("💡 Too HIGH!")`

#### **3\. CHANGELOG.md Update**

`## [v0.3.0] - Added Robust Guardrails`  
`### Added`  
``- Input validation using `.isdigit()` to prevent runtime crashes (LO4).``  
`- Range validation (1–100) to ensure valid guesses.`  
``- `continue` statements to bypass invalid turn increments (LO2).``

### **📍 Step 4: CARD 4 – Design Victory Reward Banner (LO3)**

**Board Move:** Move **\[CARD 4\]** to **IN PROGRESS** → **AI TESTING & LOGGING** → **DONE**

#### **1\. learning\_log.ipynb Entry**

**Intent:** Display a dynamic star pattern when the player wins. Fewer attempts used \= smaller/cleaner pattern; fast performance reward.

**AI Prompt:**

*"Explain how nested for loops work by showing me how to print a triangle pattern made of star symbols (⭐)."*

**AI Explanation & Reflection:**

An outer for loop controls how many rows to print, while an inner for loop prints the stars on that specific row. Using end="" in print() keeps stars on the same line until the inner loop finishes.

#### **2\. Python Code (Incremental Version 0.4.0)**

`# Version 0.4.0 - Added Nested Loop Victory Pattern (Snippet insertion at winning branch)`  
`if guess == secret_number:`  
    `print(f"\n🎉 Correct! You won in {attempts} attempt(s)!")`  
      
    `# LO3: Nested Loop Pattern`  
    `print("\n--- PERFORMANCE BANNER ---")`  
    `for row in range(1, attempts + 1):  # Outer loop for rows`  
        `for star in range(row):          # Inner loop for items per row`  
            `print("⭐", end="")`  
        `print()                          # Newline after inner loop completes`  
    `print("---------------------------\n")`  
      
    `break`

#### **3\. CHANGELOG.md Update**

`## [v0.4.0] - Integrated Nested Loops`  
`### Added`  
``- Nested `for` loop logic inside victory branch to draw dynamic performance banner (LO3).``

### **📍 Step 5: CARD 5 – Audit, Refactor & Replay Option (LO2 & LO4)**

**Board Move:** Move **\[CARD 5\]** to **IN PROGRESS** → **AI TESTING & LOGGING** → **DONE**

#### **1\. learning\_log.ipynb Entry**

**Intent:** Wrap the game in a main loop so players can restart without re-running the script, and ensure no infinite loop states remain.

**AI Prompt:**

*"Can you review my entire script to audit for potential infinite loops and show me how to wrap everything in an outer replay loop?"*

**AI Explanation & Reflection:**

Wrapping the game inside an outer while True loop allows game sessions to repeat. The inner loop manages turns, and an outer break terminates the game session completely if the user answers "no" to playing again.

#### **2\. Python Code (Final Version 1.0.0)**

`# Version 1.0.0 - Full Production Build`  
`import random`

`def run_guessing_game():`  
    `# OUTERE LOOP: Manages continuous sessions (LO1)`  
    `while True:`  
        `secret_number = random.randint(1, 100)`  
        `max_attempts = 7`  
        `attempts = 0`  
        `has_won = False`

        `print("\n=========================================")`  
        `print("   WELCOME TO THE NUMBER GUESSING GAME   ")`  
        `print("=========================================")`

        `# INNER LOOP: Manages turns within a game (LO1)`  
        `while attempts < max_attempts:`  
            `user_input = input(f"[Attempt {attempts + 1}/{max_attempts}] Guess (1-100): ").strip()`

            `if not user_input.isdigit():`  
                `print("⚠️ Invalid input! Please enter digits only.")`  
                `continue  # LO2`

            `guess = int(user_input)`

            `if guess < 1 or guess > 100:`  
                `print("⚠️ Out of range! Stay between 1 and 100.")`  
                `continue  # LO2`

            `attempts += 1`

            `if guess == secret_number:`  
                `has_won = True`  
                `print(f"\n🎉 Correct! You won in {attempts} attempt(s)!")`  
                  
                `# LO3: Nested Loop Reward`  
                `print("\n--- PERFORMANCE BANNER ---")`  
                `for row in range(1, attempts + 1):`  
                    `for star in range(row):`  
                        `print("⭐", end="")`  
                    `print()`  
                `print("---------------------------\n")`  
                `break  # Exit inner loop (LO2)`

            `elif guess < secret_number:`  
                `print("💡 Hint: Too LOW!")`  
            `else:`  
                `print("💡 Hint: Too HIGH!")`

        `if not has_won:`  
            `print(f"\n❌ Game Over! The number was {secret_number}.")`

        `# Session termination check (LO2)`  
        `replay = input("Play again? (yes/no): ").strip().lower()`  
        `if replay not in ['yes', 'y']:`  
            `print("Thanks for playing!")`  
            `break  # Exit outer loop (LO2)`

`if __name__ == "__main__":`  
    `run_guessing_game()`

#### **3\. CHANGELOG.md Update**

`## [v1.0.0] - Production Ready Release`  
`### Added`  
``- Main function wrapper `run_guessing_game()`.``  
``- Outer `while True` replay loop with session termination control (LO1, LO2).``  
`### Audited`  
`- Verified all loop exit paths; zero risk of infinite loops (LO4).`

### **📍 Step 6: CARD 6 – Final Process Documentation (LO5)**

**Board Move:** Move **\[CARD 6\]** to **IN PROGRESS** → **AI TESTING & LOGGING** → **DONE**

The student performs a final audit against the rubric:

> 1. **Code Execution:** Script runs cleanly without errors.  
> 2. **learning\_log.ipynb Verification:** Contains 5 structured prompts, AI explanations, and personal reflections mapping directly to LO1 through LO4.  
> 3. **CHANGELOG.md Verification:** Version history cleanly traces incremental changes from v0.1.0 to v1.0.0.

## **🏁 Final Board State**

`+-----------------------------------------------------------------------------------+`  
`| BACKLOG: None                                                                     |`  
`| IN PROGRESS: None                                                                 |`  
`| AI TESTING & LOGGING: None                                                        |`  
`| DONE: [CARD 1] [CARD 2] [CARD 3] [CARD 4] [CARD 5] [CARD 6]                       |`  
`+-----------------------------------------------------------------------------------+`

### **✅ Project Execution Summary**

| Artifact | Location / File | Rubric Alignment |
| :---- | :---- | :---- |
| **Executable Script** | main.py | Earns **4/4** on *Loop Logic & Technical Accuracy* and *Algorithmic Thinking*. |
| **Prompt Log** | learning\_log.ipynb | Earns **4/4** on *Reflective Development Process* (LO5) & AI Ethics compliance. |
| **Version History** | CHANGELOG.md | Demonstrates professional software delivery and incremental development. |

---

