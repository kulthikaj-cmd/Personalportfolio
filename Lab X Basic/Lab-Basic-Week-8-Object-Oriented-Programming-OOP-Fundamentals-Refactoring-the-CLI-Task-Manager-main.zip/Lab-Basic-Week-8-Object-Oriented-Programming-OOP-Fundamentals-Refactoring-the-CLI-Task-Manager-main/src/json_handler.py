import json
import os
from .utils import setup_logging, ensure_directory_exists

logger = setup_logging(__name__)

class JSONHandler:
    def read_json(self, file_path):
        if not os.path.exists(file_path):
            logger.error("JSON file not found: %s", file_path)
            return None
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                return json.load(file)
        except (OSError, json.JSONDecodeError) as exc:
            logger.error("Could not read JSON: %s", exc)
            return None

    def write_json(self, data, file_path, indent=2):
        ensure_directory_exists(os.path.dirname(file_path))
        try:
            with open(file_path, "w", encoding="utf-8") as file:
                json.dump(data, file, indent=indent, ensure_ascii=False)
                file.write("\\n")
            logger.info("Wrote updated inventory to %s", file_path)
            return True
        except OSError as exc:
            logger.error("Could not write JSON: %s", exc)
            return False

    def update_inventory(self, inventory_data, product_id, new_stock_level):
        if not isinstance(inventory_data, list):
            return False
        for product in inventory_data:
            if product.get("id") == product_id:
                product["stock"] = new_stock_level
                return True
        logger.warning("Product not found: %s", product_id)
        return False

    def add_product(self, inventory_data, new_product):
        if not isinstance(inventory_data, list):
            return False
        inventory_data.append(new_product)
        return True
