import csv
import os
from .utils import setup_logging, ensure_directory_exists

logger = setup_logging(__name__)

class CSVHandler:
    def read_csv_as_dicts(self, file_path):
        if not os.path.exists(file_path):
            logger.error("CSV file not found: %s", file_path)
            return None
        try:
            with open(file_path, "r", newline="", encoding="utf-8") as file:
                data = list(csv.DictReader(file))
            logger.info("Read %s sales rows", len(data))
            return data
        except (OSError, csv.Error) as exc:
            logger.error("Could not read CSV: %s", exc)
            return None

    def write_dicts_to_csv(self, data, file_path, fieldnames):
        ensure_directory_exists(os.path.dirname(file_path))
        try:
            with open(file_path, "w", newline="", encoding="utf-8") as file:
                writer = csv.DictWriter(file, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(data)
            logger.info("Wrote %s rows to %s", len(data), file_path)
            return True
        except (OSError, csv.Error) as exc:
            logger.error("Could not write CSV: %s", exc)
            return False

    def process_sales_data(self, sales_data, min_sale_amount=100.0):
        total_sales, total_price, count = 0.0, 0.0, 0
        filtered = []
        for row in sales_data:
            try:
                amount = float(row.get("Amount", 0))
                price = float(row.get("Price", 0))
            except (ValueError, TypeError):
                logger.warning("Skipping invalid sales row: %s", row)
                continue
            total_sales += amount
            total_price += price
            count += 1
            if amount >= min_sale_amount:
                filtered.append(row)
        summary = {
            "Total Sales": f"{total_sales:.2f}",
            "Average Item Price": f"{(total_price / count if count else 0):.2f}",
            "Filtered Sales Count": len(filtered)
        }
        return {"filtered_sales": filtered, "summary": summary}
