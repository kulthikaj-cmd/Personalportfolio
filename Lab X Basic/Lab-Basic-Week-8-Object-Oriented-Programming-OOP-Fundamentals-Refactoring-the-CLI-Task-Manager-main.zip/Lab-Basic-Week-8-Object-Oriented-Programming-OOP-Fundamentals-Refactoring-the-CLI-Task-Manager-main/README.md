# Week 8 LabX BASIC — Automating with CSV and JSON Data

This project follows the supplied Week 8 LabX BASIC PDF.

## Features
- Read sales records with `csv.DictReader`.
- Calculate total sales and average item price.
- Filter records where `Amount >= 100` and write a summary row to `data/output_filtered_sales.csv`.
- Read and update inventory JSON, change stock for `PROD001` and `PROD003`, add `PROD004`, and write `data/output_updated_inventory.json`.
- Screenshot previews of both output files are in `screenshots/`.

## Run
Python 3 is required. The project uses only the Python standard library.

```bash
python main.py
```

## Output files
- `data/output_filtered_sales.csv`
- `data/output_updated_inventory.json`

## GitHub submission
Create a new repository on GitHub, then upload/push the contents of this folder. Make sure the `screenshots/` folder is included in the repository.
