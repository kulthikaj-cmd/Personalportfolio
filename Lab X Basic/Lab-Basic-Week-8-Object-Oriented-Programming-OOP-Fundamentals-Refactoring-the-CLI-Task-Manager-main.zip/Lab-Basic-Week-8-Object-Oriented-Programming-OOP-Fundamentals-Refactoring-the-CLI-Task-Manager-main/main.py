import os
from src.csv_handler import CSVHandler
from src.json_handler import JSONHandler
from src.utils import setup_logging, ensure_directory_exists

logger = setup_logging(__name__)

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    ensure_directory_exists(data_dir)

    csv_handler = CSVHandler()
    json_handler = JSONHandler()
    sales_path = os.path.join(data_dir, "input_sales.csv")
    filtered_path = os.path.join(data_dir, "output_filtered_sales.csv")
    inventory_path = os.path.join(data_dir, "input_inventory.json")
    updated_path = os.path.join(data_dir, "output_updated_inventory.json")

    logger.info("--- Starting CSV workflow ---")
    sales = csv_handler.read_csv_as_dicts(sales_path)
    if sales is not None:
        result = csv_handler.process_sales_data(sales, min_sale_amount=100.0)
        fieldnames = list(sales[0].keys()) if sales else ["OrderID", "Product", "Amount", "Price", "Customer"]
        summary = result["summary"]
        summary_row = {
            "OrderID": "SUMMARY",
            "Product": "Total/Avg",
            "Amount": summary["Total Sales"],
            "Price": summary["Average Item Price"],
            "Customer": f'Count: {summary["Filtered Sales Count"]}'
        }
        csv_handler.write_dicts_to_csv(result["filtered_sales"] + [summary_row], filtered_path, fieldnames)

    logger.info("--- Starting JSON workflow ---")
    inventory = json_handler.read_json(inventory_path)
    if inventory is not None:
        json_handler.update_inventory(inventory, "PROD001", 60)
        json_handler.update_inventory(inventory, "PROD003", 75)
        json_handler.add_product(inventory, {
            "id": "PROD004",
            "name": "Gaming Headset",
            "category": "Audio",
            "stock": 90,
            "details": {"brand": "SoundBlaster", "features": ["Noise Cancelling", "RGB"]}
        })
        json_handler.write_json(inventory, updated_path, indent=2)
    logger.info("All workflows completed.")

if __name__ == "__main__":
    main()
