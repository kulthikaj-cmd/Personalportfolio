# document-automator/src/__init__.py
# Package marker file
