# Week 11 LabX BASIC: Automating PDFs & Word Documents

This project demonstrates how to automate common tasks involving PDF and Word documents using Python. It leverages `PyPDF2` for PDF text extraction and merging, and `python-docx` for Word document creation, formatting, and structured table assembly.

![VS Code PDF Screenshot](screenshots/screenshot_merged_pdf.png)
*Figure 1: Merged PDF output preview inside Visual Studio Code environment.*

![VS Code Word Screenshot](screenshots/screenshot_output_docx.png)
*Figure 2: Generated Word report (`output_report.docx`) preview inside Visual Studio Code.*

## Key Concepts Demonstrated
* **PDF Text Extraction**: Reading structured text content page-by-page from PDF files.
* **PDF Merging & Splitting**: Combining multiple PDF documents into a unified file (`merged_output.pdf`).
* **Word Document Creation**: Programmatically generating structured `.docx` files.
* **Rich Formatting in Word**: Adding headings, bold/italic styled runs, custom alignments, and data tables.
* **Modular Project Architecture**: Clean separation of responsibilities into `pdf_processor.py`, `word_processor.py`, and `utils.py`.
* **Logging & Error Handling**: Comprehensive console logging and robust exception management.

## Project Structure
```text
document-automator/
├── src/
│   ├── __init__.py         # Python package marker
│   ├── pdf_processor.py    # Logic for PyPDF2 operations (extract, merge, split)
│   ├── word_processor.py   # Logic for python-docx operations (create, add content, tables)
│   └── utils.py            # General utilities (logging, directory creation)
├── documents/
│   ├── input_article.pdf   # Sample PDF for text extraction
│   ├── dummy_doc1.pdf      # Sample PDF 1 for merging
│   ├── dummy_doc2.pdf      # Sample PDF 2 for merging
│   ├── output_report.docx  # Generated Word document report
│   └── merged_output.pdf   # Generated merged PDF document
├── screenshots/
│   ├── screenshot_merged_pdf.png   # VS Code preview screenshot for merged PDF
│   └── screenshot_output_docx.png  # VS Code preview screenshot for output Word report
├── main.py                 # Main entry point orchestrating document workflows
├── .gitignore              # Files and patterns ignored by Git
└── README.md               # Project overview and instruction guide
```

## Setup & How to Run
1. **Clone the repository:**
   ```bash
   git clone https://github.com/YOUR_USERNAME/document-automator.git
   cd document-automator
   ```

2. **Set up Virtual Environment & Install Dependencies:**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install PyPDF2 python-docx
   ```

3. **Run the Automation Pipeline:**
   ```bash
   python main.py
   ```

   The pipeline will:
   - Extract text from `documents/input_article.pdf`.
   - Generate `documents/output_report.docx` complete with headers, extracted body, and summary metrics table.
   - Combine `dummy_doc1.pdf` and `dummy_doc2.pdf` into `documents/merged_output.pdf`.
