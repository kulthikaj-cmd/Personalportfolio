# LabX BASIC: Automating Communications (Email & SMS)

Python project demonstrating SMTP email sending, PDF attachments, IMAP unread-email processing, and optional email-to-SMS gateways.

## Setup (Windows / VS Code)

1. Open this folder in VS Code.
2. In Terminal, create and activate a virtual environment:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```
3. Install dependency:
   ```powershell
   py -m pip install python-dotenv
   ```
4. Copy `.env.example` to `.env` and fill in your Gmail address and Google App Password.
5. Run:
   ```powershell
   py main.py
   ```

## Security
- Never upload `.env` or your app password to GitHub.
- For Gmail, use a Google App Password with 2-Step Verification, not your normal password.
- SMS email gateways are carrier-dependent and may not work in every country. Skip the SMS step if you do not have a supported gateway.
- Test with an email address you own or have permission to contact.
