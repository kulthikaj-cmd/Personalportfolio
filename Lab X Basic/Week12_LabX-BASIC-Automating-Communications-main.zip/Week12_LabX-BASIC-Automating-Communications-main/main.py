import os
from src.utils import get_env_variable, ensure_directory_exists, logging
from src.email_sender import EmailSender
from src.email_receiver import EmailReceiver
from src.sms_gateway import SMSGateway

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    attachments_dir = os.path.join(data_dir, "attachments")
    ensure_directory_exists(attachments_dir)

    try:
        sender_email = get_env_variable("SENDER_EMAIL")
        app_password = get_env_variable("SENDER_APP_PASSWORD")
        smtp_server = get_env_variable("SMTP_SERVER", "smtp.gmail.com")
        smtp_port = int(get_env_variable("SMTP_PORT", "587"))
        imap_server = get_env_variable("IMAP_SERVER", "imap.gmail.com")
    except ValueError as exc:
        logging.error("%s", exc)
        return

    email_sender = EmailSender(smtp_server, smtp_port, sender_email, app_password)
    email_receiver = EmailReceiver(imap_server, sender_email, app_password)
    sms_gateway = SMSGateway(email_sender)

    print("\\n1) Send a test email")
    recipient = input("Recipient email (press Enter to skip): ").strip()
    if recipient:
        email_sender.send_email(recipient, "Automated Python Test Email",
                                "Hello from your Python automation script!")

    print("\\n2) Send an email with PDF attachment")
    recipient = input("Recipient email (press Enter to skip): ").strip()
    pdf_path = os.path.join(data_dir, "dummy_report.pdf")
    if recipient and os.path.exists(pdf_path):
        email_sender.send_email(recipient, "Python Test Email with Attachment",
                                "Please find the report attached.", pdf_path)
    elif recipient:
        logging.warning("data/dummy_report.pdf was not found.")

    print("\\n3) Send SMS through an email-to-SMS gateway (optional)")
    gateway = input("Full gateway email address (press Enter to skip): ").strip()
    if gateway:
        sms_gateway.send_sms(gateway, "Hello from Python! Automated test message.")

    print("\\n4) Check unread emails")
    choice = input("Check inbox for unread emails? (y/n): ").strip().lower()
    if choice == "y":
        email_receiver.receive_unread_emails(attachments_dir)

    logging.info("Communication automation tasks completed.")

if __name__ == "__main__":
    main()
