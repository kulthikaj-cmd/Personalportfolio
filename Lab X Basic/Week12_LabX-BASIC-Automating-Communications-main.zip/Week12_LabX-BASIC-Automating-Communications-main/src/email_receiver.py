import imaplib
import email
from email.header import decode_header
from .utils import logging, ensure_directory_exists
import os

class EmailReceiver:
    def __init__(self, imap_server, sender_email, sender_password):
        self.imap_server = imap_server
        self.sender_email = sender_email
        self.sender_password = sender_password

    def receive_unread_emails(self, download_dir):
        downloaded = []
        try:
            with imaplib.IMAP4_SSL(self.imap_server) as mail:
                mail.login(self.sender_email, self.sender_password)
                mail.select("INBOX")
                status, data = mail.search(None, "UNSEEN")
                if status != "OK":
                    logging.error("Could not search inbox.")
                    return downloaded

                ensure_directory_exists(download_dir)
                for uid in data[0].split():
                    status, msg_data = mail.fetch(uid, "(RFC822)")
                    if status != "OK":
                        continue
                    msg = email.message_from_bytes(msg_data[0][1])
                    subject_parts = decode_header(msg.get("Subject", ""))
                    subject = "".join(
                        part.decode(enc or "utf-8", errors="replace") if isinstance(part, bytes) else part
                        for part, enc in subject_parts
                    )
                    logging.info("From: %s", msg.get("From", ""))
                    logging.info("Subject: %s", subject)
                    body = ""
                    for part in msg.walk():
                        if part.get_content_disposition() == "attachment":
                            filename = part.get_filename()
                            if filename:
                                path = os.path.join(download_dir, os.path.basename(filename))
                                with open(path, "wb") as f:
                                    f.write(part.get_payload(decode=True) or b"")
                                downloaded.append(path)
                                logging.info("Downloaded attachment: %s", path)
                        elif part.get_content_type() == "text/plain" and part.get_content_disposition() != "attachment":
                            payload = part.get_payload(decode=True)
                            if payload:
                                body += payload.decode(part.get_content_charset() or "utf-8", errors="replace")
                    logging.info("Body snippet: %s", body[:200])
                    mail.store(uid, "+FLAGS", "\\Seen")
            return downloaded
        except Exception as exc:
            logging.error("Email receiving failed: %s", exc)
            return downloaded
