import logging
import os
from dotenv import load_dotenv

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def get_env_variable(name, default=None):
    value = os.getenv(name, default)
    if value is None:
        raise ValueError(f"Environment variable '{name}' is not set. Check your .env file.")
    return value

def ensure_directory_exists(path):
    os.makedirs(path, exist_ok=True)
