from .utils import logging

class SMSGateway:
    def __init__(self, email_sender):
        self.email_sender = email_sender

    def send_sms(self, gateway_email, message):
        if "@" not in gateway_email:
            logging.error("Use a full carrier email-to-SMS gateway address.")
            return False
        return self.email_sender.send_email(gateway_email, "", message)
