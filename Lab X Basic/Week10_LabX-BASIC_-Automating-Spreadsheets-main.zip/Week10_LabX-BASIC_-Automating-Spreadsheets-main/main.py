from pathlib import Path
from src.excel_processor import ExcelProcessor


def main():
    project_dir = Path(__file__).resolve().parent
    input_file = project_dir / "data" / "input_sales.xlsx"
    output_file = project_dir / "data" / "output_sales_report.xlsx"
    output_file.parent.mkdir(parents=True, exist_ok=True)

    if not input_file.exists():
        print(f"Error: Input file '{input_file}' not found.")
        return

    processor = ExcelProcessor()
    print(f"Starting sales data processing from '{input_file.relative_to(project_dir)}'...")
    success = processor.process_sales_data(str(input_file), str(output_file))
    if success:
        print(f"Sales report successfully generated and saved to '{output_file.relative_to(project_dir)}'.")
    else:
        print("Failed to generate sales report.")


if __name__ == "__main__":
    main()
