import openpyxl
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.utils import get_column_letter


class ExcelProcessor:
    """Read sales data and generate a formatted Excel sales report."""

    def create_workbook(self, filename="new_workbook.xlsx"):
        wb = openpyxl.Workbook()
        if "Sheet" in wb.sheetnames:
            del wb["Sheet"]
        return wb

    def load_workbook(self, filename):
        try:
            wb = openpyxl.load_workbook(filename, data_only=True)
            print(f"Workbook '{filename}' loaded successfully.")
            return wb
        except FileNotFoundError:
            print(f"Error: Workbook '{filename}' not found.")
            return None
        except Exception as exc:
            print(f"Error loading workbook '{filename}': {exc}")
            return None

    def save_workbook(self, workbook, filename):
        try:
            workbook.save(filename)
            print(f"Workbook saved to '{filename}'.")
            return True
        except Exception as exc:
            print(f"Error saving workbook to '{filename}': {exc}")
            return False

    def process_sales_data(self, input_filename, output_filename):
        """Calculate each item's total and the grand total, then save a report."""
        input_wb = self.load_workbook(input_filename)
        if input_wb is None:
            return False

        input_sheet = input_wb.active
        output_wb = self.create_workbook()
        output_sheet = output_wb.create_sheet("Sales Report", 0)

        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="4CAF50", end_color="4CAF50", fill_type="solid")
        total_font = Font(bold=True, color="000000")
        total_fill = PatternFill(start_color="FFEB3B", end_color="FFEB3B", fill_type="solid")
        thin = Side(style="thin")
        border = Border(left=thin, right=thin, top=thin, bottom=thin)
        currency_format = '#,##0.00'

        headers = ["Product Name", "Quantity", "Unit Price", "Total Price"]
        for col_num, header in enumerate(headers, 1):
            cell = output_sheet.cell(row=1, column=col_num, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.border = border
            cell.alignment = Alignment(horizontal="center", vertical="center")

        grand_total = 0.0
        output_row = 2
        for row_index, row in enumerate(input_sheet.iter_rows(min_row=2, values_only=True), 2):
            if not any(value is not None for value in row):
                continue
            product_name = row[0] if len(row) > 0 else None
            quantity = row[1] if len(row) > 1 else 0
            unit_price = row[2] if len(row) > 2 else 0.0
            try:
                quantity = int(quantity)
                unit_price = float(unit_price)
            except (ValueError, TypeError):
                print(f"Warning: Skipping row {row_index} due to invalid number format: {row}")
                continue

            total_price = quantity * unit_price
            grand_total += total_price
            output_sheet.cell(row=output_row, column=1, value=product_name).border = border
            output_sheet.cell(row=output_row, column=2, value=quantity).border = border
            unit_cell = output_sheet.cell(row=output_row, column=3, value=unit_price)
            unit_cell.number_format = currency_format
            unit_cell.border = border
            total_cell = output_sheet.cell(row=output_row, column=4, value=total_price)
            total_cell.number_format = currency_format
            total_cell.border = border
            output_row += 1

        output_sheet.merge_cells(start_row=output_row, start_column=1,
                                 end_row=output_row, end_column=3)
        label_cell = output_sheet.cell(row=output_row, column=1, value="Grand Total:")
        label_cell.font = total_font
        label_cell.fill = total_fill
        label_cell.alignment = Alignment(horizontal="right", vertical="center")
        value_cell = output_sheet.cell(row=output_row, column=4, value=grand_total)
        value_cell.font = total_font
        value_cell.fill = total_fill
        value_cell.number_format = currency_format
        value_cell.border = border
        for cell in output_sheet[output_row][:3]:
            cell.fill = total_fill
            cell.border = border

        for col_num in range(1, len(headers) + 1):
            column_letter = get_column_letter(col_num)
            max_length = max(
                (len(str(cell.value)) for cell in output_sheet[column_letter] if cell.value is not None),
                default=0,
            )
            output_sheet.column_dimensions[column_letter].width = max_length + 2

        output_sheet.freeze_panes = "A2"
        return self.save_workbook(output_wb, output_filename)
