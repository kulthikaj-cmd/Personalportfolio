"""Spreadsheet automation package."""
