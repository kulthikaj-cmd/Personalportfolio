# Changelog

All notable changes to the **Pet Adoption Explorer** project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project follows Semantic Versioning.

---

## [v0.3.0] - Sprint 3: Data Analysis, Visualization & Advanced Features

**Period:** 25–29 September 2026  
**Status:** Completed

Sprint 3 focused on extending the Pet Adoption Explorer from a data presentation system into an analytical system capable of processing, analyzing, visualizing, filtering, sorting, and comparing pet adoption data.

### Added

- Added Data Processing and Data Normalization workflow for pet data.
- Added data preparation for pet adoption attributes (category, location, housing suitability, initial/monthly costs, and age).
- Added Exploratory Data Analysis (EDA) for pet records using Pandas.
- Added descriptive statistical analysis for pet maintenance costs and age distribution.
- Added summary statistics including count, mean, median, minimum, maximum, and standard deviation for monthly adoption expenses.
- Added pet category frequency and proportion analysis (Dogs, Cats, Rabbits, Rodents, Birds).
- Added housing suitability proportion analysis (Condo vs. House).
- Added Statistics Dashboard page.
- Added Data Visualizations using Altair for pet statistics.
- Added Category Distribution visualization.
- Added Monthly Cost Analysis by Category visualization.
- Added Suitable Housing Proportion visualization.
- Added Age Distribution visualization.
- Added Initial vs. Monthly Cost Comparison visualization.
- Added Advanced Filtering for Category, Location, Suitable Housing, and Max Monthly Cost.
- Added Advanced Sorting for Monthly Cost, Age, and Pet Name (ascending/descending).
- Added Advanced Pet Comparison functionality for comparing 2–3 pets side-by-side.
- Added empty-state handling for cases where no pet matches the selected filters.
- Added Sprint 3 statistical analysis test cases.
- Added Sprint 3 visualization and integration test coverage.

### Changed

- Updated the application workflow to include Data Processing and Analysis before displaying statistical results.
- Updated the Dashboard workflow to support Statistics and Altair Data Visualization.
- Updated pet filtering to support multi-condition filtering.
- Updated pet sorting to support multiple fields and directions.
- Updated the Dashboard to support side-by-side pet comparisons.
- Updated the project structure by adding `src/analysis/statistics.py` and `src/components/statistics_page.py`.
- Updated project documentation to reflect Sprint 3 implementation and completed features.

### Fixed

- Improved handling of missing or incomplete cost values during statistical calculations using numeric coercion.
- Improved handling of empty datasets after applying filters to display informative empty states without crashing.
- Fixed integration issues between processed DataFrame records and Altair chart components.

### Testing

Sprint 3 testing covered:

- Data Normalization
- Missing Values Handling
- Descriptive Statistics Calculation
- Category Frequency & Proportion Analysis
- Multi-condition Filtering
- Advanced Sorting
- Pet Comparison Table Rendering
- Empty Dataset Handling
- Statistics Page Rendering
- Integration Testing

---

## Planner / Coder / Debugger Roles — Sprint 3

| สมาชิก | ชื่อเล่น | Role | หน้าที่ |
|---|---|---|---|
| นายเดโชชิต โตวินัส | ออม | Planner | Defined Sprint 3 scope, requirements, task allocation, Definition of Done, progress tracking, and Sprint 3 documentation. |
| นายชิษณุพงศ์ ซู | คิม | Coder | Developed analysis layer (`statistics.py`), statistics page, Altair charts, advanced filters, sorting, and comparison features. |
| นายภานุวัฒน์ ผองแก้ว | ฟลุ๊ค | Debugger | Tested data processing, statistical outputs, visualizations, multi-condition filtering, sorting, edge cases, and verified fixes. |

---

## [v0.2.0] - Sprint 2: Web Application, Database & Core Logic

**Period:** 20–24 September 2026  
**Status:** Completed

Sprint 2 transformed the project from a static prototype into a fully connected Web Application backed by a SQLite database.

### Added

- Added SQLite database integration (`pet_adoption.db`) for real pet records and budget factors.
- Added Pet Application Service layer to separate business logic from UI.
- Added dynamic search functionality supporting name and breed searches (case-insensitive & partial match).
- Added Category Filter functionality (Dogs, Cats, Rabbits, Rodents, Birds).
- Added Pet Comparison Tool for side-by-side comparison of 2–3 pets.
- Added Match Quiz Engine with 4-question lifestyle matching algorithm.
- Added Dynamic Budget Calculator Engine with timeline slider (1–36 months).
- Added Favorites Management System using persistent `st.session_state`.
- Added automated unit tests using `pytest` for database, service, quiz engine, and data processing.
- Added Sprint 2 daily task allocation and contribution metrics.

### Changed

- Changed data source from static local sample dictionaries to a SQLite database.
- Updated project structure by organizing components (`src/components/`), database (`src/database/`), and services (`src/services/`).
- Updated Session State management to prevent data loss across page navigation.
- Updated error handling for database queries and empty search states.

### Fixed

- Fixed Session State reset issues where saved favorites were cleared when switching pages in Streamlit.
- Fixed handling of missing image URLs by providing default cover images.
- Fixed database query performance to render results in under 1 second.

## Planner / Coder / Debugger Roles — Sprint 2

| สมาชิก | ชื่อเล่น | Role | หน้าที่ |
|---|---|---|---|
| นายภานุวัฒน์ ผองแก้ว | ฟลุ๊ค | Planner | Defined Sprint 2 scope, requirements, system architecture, database schema, task allocation, and Sprint 2 documentation. |
| นายเดโชชิต โตวินัส | ออม | Coder | Developed Streamlit Web Application, SQLite database connection, service layer, Match Quiz logic, and Budget Calculator engine. |
| นายชิษณุพงศ์ ซู | คิม | Debugger / QA | Tested database operations, UI state persistence, search/filter logic, edge cases, and verified Sprint 2 features. |

---

## [v0.1.0] - Sprint 1: Web Foundation & UI Prototype

**Period:** 10–15 September 2026  
**Status:** Completed

Sprint 1 established the initial application foundation and interactive Web UI prototype using Streamlit and a local sample dataset.

### Added

- Created Pet Adoption Explorer project.
- Added Top Navigation Bar with 7 main menus (Home, Explore, Compare, Match Quiz, Budget Calc, Favorites, Admin).
- Added Hero Banner and Pet of the Day highlight section.
- Added local sample pet dataset (Boba, Cookie, Milo, etc.).
- Added category filtering buttons.
- Added basic search component.
- Added basic pet comparison layout.
- Added Match Quiz UI flow.
- Added Budget Calculator UI layout.
- Added Favorites empty state handling.
- Added Sprint 1 QA test cases and daily task allocation.

### Changed

- Updated project documentation based on Sprint 1 requirements.
- Updated Project Pitch and Master Plan documents.
- Updated Learning Log and Change Log for Sprint 1.

## Planner / Coder / Debugger Roles — Sprint 1

| สมาชิก | ชื่อเล่น | Role | หน้าที่ |
|---|---|---|---|
| โดนัท | Planner | Defined project scope, requirements, Sprint 1 plan, UI wireframes, documentation, and task allocation. |
| ฟีฟ่า | Coder | Developed Streamlit layout, top navigation bar, Home page, search UI, and core UI components. |
| ภีม | Debugger / QA | Tested UI navigation, component layout responsiveness, edge cases, and verified Sprint 1 prototype functionality. |
