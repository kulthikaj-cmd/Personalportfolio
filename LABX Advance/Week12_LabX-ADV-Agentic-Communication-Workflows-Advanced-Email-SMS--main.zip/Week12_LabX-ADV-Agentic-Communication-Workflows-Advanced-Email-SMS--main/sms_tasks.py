import logging
from .email_tasks import EmailTasks

class SMSTasks:
    # Email-to-SMS gateways vary by carrier and country. Configure a full gateway
    # address in the JSON pipeline only when your carrier confirms support.
    def __init__(self, email_tasks):
        if not isinstance(email_tasks, EmailTasks):
            raise TypeError("SMSTasks requires an EmailTasks instance.")
        self.email_tasks = email_tasks

    def send_sms(self, gateway_addresses, message):
        if not gateway_addresses:
            logging.warning("SMS skipped: no SMS gateway addresses configured.")
            return False
        results = []
        for address in gateway_addresses:
            if "@" not in address:
                logging.warning("SMS skipped: '%s' is not a full gateway email address.", address)
                results.append(False)
                continue
            results.append(self.email_tasks.send_email(
                {"to": [address]}, " ", message, attachments=[]
            ))
        return all(results)
