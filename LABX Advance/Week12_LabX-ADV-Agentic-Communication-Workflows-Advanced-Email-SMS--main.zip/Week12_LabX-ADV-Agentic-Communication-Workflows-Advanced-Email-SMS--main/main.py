import os
import logging
from dotenv import load_dotenv
from src.config_parser import ConfigParser
from src.communication_agent import CommunicationAgent
from src.utils import ensure_directory_exists

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    load_dotenv(os.path.join(base_dir, ".env"))

    for folder in [
        "data/reports",
        "data/incoming_attachments",
        "data/attachments",
        "reports",
        "configs"
    ]:
        ensure_directory_exists(os.path.join(base_dir, folder))

    config_path = os.path.join(base_dir, "configs", "comm_pipeline_config.json")
    try:
        config = ConfigParser(config_path).load_config()
        agent = CommunicationAgent(config, base_dir)
        report_path = agent.run()
        logging.info("Communication workflow completed. Audit report: %s", report_path)
    except Exception as error:
        logging.exception("Communication workflow could not start: %s", error)

if __name__ == "__main__":
    main()
