import datetime
import json
import logging
import os
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

def get_env_variable(name, required=True, default=None):
    value = os.getenv(name, default)
    if required and not value:
        raise ValueError(f"Environment variable '{name}' is missing. Check your .env file.")
    return value

def ensure_directory_exists(path):
    os.makedirs(path, exist_ok=True)

def log_audit_entry(audit_log, status, message, task_type="N/A", details=None):
    audit_log.append({
        "timestamp": datetime.datetime.now().isoformat(timespec="seconds"),
        "status": status,
        "task_type": task_type,
        "message": message,
        "details": details or {}
    })

def save_audit_report(audit_log, output_dir):
    ensure_directory_exists(output_dir)
    filename = f"audit_report_comm_{datetime.datetime.now():%Y%m%d_%H%M%S}.json"
    path = os.path.join(output_dir, filename)
    with open(path, "w", encoding="utf-8") as file:
        json.dump(audit_log, file, indent=4, ensure_ascii=False)
    logging.info("Audit report saved to: %s", path)
    return path
