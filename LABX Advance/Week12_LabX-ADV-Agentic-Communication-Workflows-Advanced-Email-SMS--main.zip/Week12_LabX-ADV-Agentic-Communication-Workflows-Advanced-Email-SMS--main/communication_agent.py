import datetime
import logging
import os
from .email_tasks import EmailTasks
from .sms_tasks import SMSTasks
from .template_renderer import TemplateRenderer
from .utils import get_env_variable, log_audit_entry, save_audit_report

class CommunicationAgent:
    def __init__(self, config, base_dir):
        self.config = config
        self.base_dir = base_dir
        self.context = {
            "report_name": "DailySalesSummary",
            "report_date": datetime.date.today().isoformat(),
            "sales_figure": 12345.67,
            "total_customers": 500
        }
        self.audit_log = []
        self.renderer = TemplateRenderer()
        self.email_tasks = EmailTasks(
            get_env_variable("SMTP_SERVER"),
            get_env_variable("SMTP_PORT"),
            get_env_variable("IMAP_SERVER"),
            get_env_variable("SENDER_EMAIL"),
            get_env_variable("SENDER_APP_PASSWORD")
        )
        self.sms_tasks = SMSTasks(self.email_tasks)

    def render(self, value):
        return self.renderer.render(value, self.context)

    def absolute_paths(self, paths):
        return [os.path.join(self.base_dir, self.render(path)) for path in paths]

    def process_task(self, task):
        task_type = task["type"]
        name = task["name"]
        params = task.get("parameters", {})
        log_audit_entry(self.audit_log, "INFO", f"Starting {name}", task_type)
        try:
            if task_type == "send_email":
                recipients = {
                    key: [self.render(item) for item in values]
                    for key, values in params.get("recipients", {}).items()
                }
                subject = self.render(params.get("subject_template", ""))
                body = self.render(params.get("body_template", ""))
                attachments = self.absolute_paths(params.get("attachments", []))
                self.email_tasks.send_email(
                    recipients, subject, body, attachments, params.get("is_html", False)
                )
                output = {"subject": subject, "recipients": recipients}
            elif task_type == "send_sms":
                gateways = [self.render(x) for x in params.get("gateway_addresses", [])]
                message = self.render(params.get("message_template", ""))
                self.sms_tasks.send_sms(gateways, message)
                output = {"gateway_addresses": gateways}
            elif task_type == "process_inbox":
                criteria = params.get("search_criteria", {})
                sender = self.render(criteria["from_sender"]) if criteria.get("from_sender") else None
                subject = self.render(criteria["subject_contains"]) if criteria.get("subject_contains") else None
                uids = self.email_tasks.search_emails(
                    params.get("mailbox", "INBOX"),
                    criteria.get("status", "UNSEEN"),
                    sender,
                    subject
                )
                processed = []
                download_dir = os.path.join(self.base_dir, params.get(
                    "download_attachments_base_dir", "data/incoming_attachments"
                ))
                for uid in uids:
                    info = self.email_tasks.fetch_email_content(uid, True, download_dir)
                    if not info:
                        continue
                    processed.append(info)
                    for rule in params.get("rules", []):
                        conditions = rule.get("if", {})
                        matched = True
                        if "subject_contains" in conditions:
                            matched &= self.render(conditions["subject_contains"]).lower() in info["subject"].lower()
                        if "body_contains" in conditions:
                            matched &= self.render(conditions["body_contains"]).lower() in info["text_body"].lower()
                        if "has_attachments" in conditions:
                            matched &= conditions["has_attachments"] == info["has_attachments"]
                        actions = rule.get("then", {})
                        if matched and actions.get("send_sms_alert"):
                            message = self.renderer.render(
                                actions.get("alert_message_template", "Email received: {subject}"),
                                {**self.context, **info}
                            )
                            gateways = [self.render(x) for x in actions.get("gateway_addresses", [])]
                            self.sms_tasks.send_sms(gateways, message)
                        if matched and actions.get("reply_with_template"):
                            reply_body = self.renderer.render(actions["reply_with_template"], {**self.context, **info})
                            reply_subject = self.renderer.render(
                                actions.get("reply_subject_template", "Re: {subject}"),
                                {**self.context, **info}
                            )
                            sender_address = info["sender"].split("<")[-1].split(">")[0].strip()
                            if "@" in sender_address:
                                self.email_tasks.send_email(
                                    {"to": [sender_address]}, reply_subject, reply_body
                                )
                output = {"processed_emails": processed, "found": len(uids)}
            else:
                raise ValueError(f"Unsupported task type: {task_type}")

            key = task.get("output_context_key")
            if key:
                self.context[key] = output
            log_audit_entry(self.audit_log, "SUCCESS", f"Completed {name}", task_type, output)
        except Exception as error:
            logging.exception("Task failed: %s", name)
            log_audit_entry(self.audit_log, "ERROR", str(error), task_type, {"task": name})

    def run(self):
        log_audit_entry(self.audit_log, "INFO", "Communication Agent started", "agent_run")
        for task in self.config.get("tasks", []):
            self.process_task(task)
        log_audit_entry(self.audit_log, "INFO", "Communication Agent finished", "agent_run")
        return save_audit_report(self.audit_log, os.path.join(self.base_dir, "reports"))
