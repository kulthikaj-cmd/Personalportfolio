import json
import os

class ConfigParser:
    def __init__(self, config_path):
        self.config_path = config_path

    def load_config(self):
        if not os.path.isfile(self.config_path):
            raise FileNotFoundError(f"Config file not found: {self.config_path}")
        with open(self.config_path, "r", encoding="utf-8") as file:
            config = json.load(file)
        if not isinstance(config.get("tasks"), list):
            raise ValueError("Configuration must contain a 'tasks' list.")
        for index, task in enumerate(config["tasks"], start=1):
            if not task.get("type") or not task.get("name"):
                raise ValueError(f"Task {index} needs both 'type' and 'name'.")
        return config
