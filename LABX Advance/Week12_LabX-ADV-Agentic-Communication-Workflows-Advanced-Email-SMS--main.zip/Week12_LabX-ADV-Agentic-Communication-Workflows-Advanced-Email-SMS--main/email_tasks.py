import email
import imaplib
import os
import smtplib
from email import policy
from email.header import decode_header, make_header
from email.message import EmailMessage
from .utils import ensure_directory_exists

class EmailTasks:
    def __init__(self, smtp_server, smtp_port, imap_server, sender_email, sender_password):
        self.smtp_server = smtp_server
        self.smtp_port = int(smtp_port)
        self.imap_server = imap_server
        self.sender_email = sender_email
        self.sender_password = sender_password

    def send_email(self, recipients, subject, body, attachments=None, is_html=False):
        to_list = recipients.get("to", [])
        cc_list = recipients.get("cc", [])
        bcc_list = recipients.get("bcc", [])
        all_recipients = to_list + cc_list + bcc_list
        if not all_recipients:
            raise ValueError("No email recipients were configured.")

        message = EmailMessage()
        message["From"] = self.sender_email
        message["To"] = ", ".join(to_list)
        if cc_list:
            message["Cc"] = ", ".join(cc_list)
        message["Subject"] = subject
        if is_html:
            message.set_content("This email contains HTML content.")
            message.add_alternative(body, subtype="html")
        else:
            message.set_content(body)

        for path in attachments or []:
            if not os.path.isfile(path):
                raise FileNotFoundError(f"Attachment not found: {path}")
            with open(path, "rb") as file:
                data = file.read()
            ext = os.path.splitext(path)[1].lower()
            subtype = "pdf" if ext == ".pdf" else "vnd.openxmlformats-officedocument.spreadsheetml.sheet" if ext == ".xlsx" else "octet-stream"
            maintype = "application"
            message.add_attachment(data, maintype=maintype, subtype=subtype, filename=os.path.basename(path))

        with smtplib.SMTP(self.smtp_server, self.smtp_port, timeout=30) as server:
            server.ehlo()
            server.starttls()
            server.ehlo()
            server.login(self.sender_email, self.sender_password)
            server.send_message(message, from_addr=self.sender_email, to_addrs=all_recipients)
        return True

    @staticmethod
    def _decode(value):
        if not value:
            return ""
        try:
            return str(make_header(decode_header(value)))
        except Exception:
            return value

    def search_emails(self, mailbox="INBOX", criteria="UNSEEN", from_sender=None, subject_contains=None):
        with imaplib.IMAP4_SSL(self.imap_server) as mail:
            mail.login(self.sender_email, self.sender_password)
            status, _ = mail.select(mailbox)
            if status != "OK":
                raise RuntimeError(f"Could not open mailbox {mailbox}")
            query = [criteria]
            if from_sender:
                query.extend(["FROM", f'"{from_sender}"'])
            if subject_contains:
                query.extend(["SUBJECT", f'"{subject_contains}"'])
            status, data = mail.search(None, *query)
            if status != "OK":
                raise RuntimeError("IMAP search failed.")
            return data[0].split()

    def fetch_email_content(self, uid, mark_as_read=True, download_attachments_dir=None):
        with imaplib.IMAP4_SSL(self.imap_server) as mail:
            mail.login(self.sender_email, self.sender_password)
            mail.select("INBOX")
            status, data = mail.fetch(uid, "(RFC822)")
            if status != "OK" or not data or not isinstance(data[0], tuple):
                return None
            msg = email.message_from_bytes(data[0][1], policy=policy.default)
            text_body = ""
            attachments = []
            for part in msg.walk():
                if part.is_multipart():
                    continue
                filename = part.get_filename()
                disposition = part.get_content_disposition()
                if filename or disposition == "attachment":
                    if filename and download_attachments_dir:
                        ensure_directory_exists(download_attachments_dir)
                        safe_name = os.path.basename(filename)
                        target = os.path.join(download_attachments_dir, safe_name)
                        with open(target, "wb") as file:
                            file.write(part.get_payload(decode=True) or b"")
                        attachments.append({"filename": safe_name, "filepath": target})
                    elif filename:
                        attachments.append({"filename": filename, "filepath": None})
                elif part.get_content_type() == "text/plain":
                    try:
                        text_body += part.get_content()
                    except Exception:
                        pass
            if mark_as_read:
                mail.store(uid, "+FLAGS", "\\Seen")
            return {
                "uid": uid.decode(errors="replace"),
                "sender": self._decode(msg.get("From")),
                "subject": self._decode(msg.get("Subject")),
                "text_body": text_body,
                "has_attachments": bool(attachments),
                "attachments_meta": attachments
            }
