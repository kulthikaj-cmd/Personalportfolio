import os
import string

class SafeTemplateDict(dict):
    def __missing__(self, key):
        return "{" + key + "}"

class TemplateRenderer:
    def render(self, template, context):
        if template is None:
            return ""
        values = dict(os.environ)
        values.update(context or {})
        # Support environment placeholders written as ${VARIABLE}.
        for key, value in list(values.items()):
            values["$" + key] = value
        return string.Formatter().vformat(str(template), [], SafeTemplateDict(values))
