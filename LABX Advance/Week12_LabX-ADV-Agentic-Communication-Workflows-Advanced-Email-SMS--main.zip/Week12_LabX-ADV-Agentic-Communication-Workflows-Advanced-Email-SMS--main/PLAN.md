# Project Plan — Agentic Communication Automator

## Objective
Build a modular, configuration-driven agent that automates multi-step email and optional SMS workflows.

## Main components
- `CommunicationAgent`: orchestrates configured tasks and maintains shared context.
- `EmailTasks`: sends emails using SMTP and searches/fetches messages using IMAP.
- `SMSTasks`: sends messages through an explicitly configured email-to-SMS gateway.
- `TemplateRenderer`: fills placeholders using environment variables and agent context.
- `ConfigParser`: loads and validates the JSON workflow.
- `utils`: environment loading, directory management, logging, and audit report generation.

## Workflow
1. Load credentials from `.env`.
2. Populate report date, sales amount, and customer count in agent context.
3. Send a templated email with PDF and Excel attachments.
4. Attempt optional SMS only when gateway addresses are configured.
5. Send a simulated data request email to the sender's inbox.
6. Search unread messages matching sender and subject criteria.
7. Download attachments, mark matching messages as read, and apply if/then rules.
8. Generate a JSON audit report.

## Security
Credentials are stored in `.env`, which is excluded by `.gitignore`. Only `.env.example` is included in the repository.

## Testing checklist
- [ ] Verify a test email arrives with both attachments.
- [ ] Verify the self-addressed request email arrives.
- [ ] Verify inbox processing downloads the PDF attachment.
- [ ] Verify the automated reply is sent for matching content.
- [ ] Verify an audit report is created under `reports/`.
- [ ] Configure and test SMS only if a supported gateway is available.

## Limitations
SMS gateway support depends on the mobile carrier and country. Gmail SMTP/IMAP access requires valid credentials and enabled IMAP.
