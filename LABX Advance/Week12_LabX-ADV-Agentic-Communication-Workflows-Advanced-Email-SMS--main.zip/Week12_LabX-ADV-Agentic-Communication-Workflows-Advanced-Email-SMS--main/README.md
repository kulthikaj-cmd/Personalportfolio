# Agentic Communication Automator
Week 12 LabX ADV — Advanced Email & SMS

A configuration-driven Python communication agent. It sends templated emails with multiple attachments, can send SMS through a configured email-to-SMS gateway, processes incoming email using rules, downloads attachments, sends automated replies, and writes a JSON audit report.

## Requirements
- Python 3.10+
- Gmail account with 2-Step Verification and an App Password
- IMAP enabled in Gmail settings
- `python-dotenv` and `openpyxl` are not required to run the agent; only `python-dotenv` is required.

## Setup on Windows / VS Code
1. Open this folder in VS Code.
2. Open Terminal in the project root.
3. Create a virtual environment:
   `py -m venv .venv`
4. Install the dependency:
   `.\.venv\Scripts\python.exe -m pip install python-dotenv`
5. Copy `.env.example` to a new file named `.env`.
6. Edit `.env` and enter your Gmail address, Google App Password, and a recipient email you can access.
7. Confirm IMAP is enabled in Gmail settings.
8. Run:
   `.\.venv\Scripts\python.exe main.py`

## Important Gmail setup
Use a Google App Password, not your normal Gmail password. Keep `.env` private. The `.gitignore` file excludes `.env` and `.venv/`; never upload credentials to GitHub.

## What the workflow does
1. Sends a dynamic daily report email to `TEST_RECIPIENT_EMAIL`, attaching `sales_report.pdf` and `summary_data.xlsx`.
2. Skips SMS unless a valid carrier-supported gateway address is configured.
3. Sends a sample request email to the sender's own inbox.
4. Searches unread inbox messages from the sender with `Data Request` in the subject, downloads attachments, marks them as read, and applies rules.
5. Replies to matching request emails and creates `reports/audit_report_comm_*.json`.

## SMS note
Email-to-SMS gateways are carrier- and country-specific. The example configuration leaves SMS gateway lists empty so the workflow can be tested without falsely claiming an SMS was delivered. Only add a gateway address after confirming it is supported by your mobile carrier.

## Project structure
```text
agentic-comm-automator/
├── src/
│   ├── __init__.py
│   ├── utils.py
│   ├── config_parser.py
│   ├── email_tasks.py
│   ├── sms_tasks.py
│   ├── template_renderer.py
│   └── communication_agent.py
├── configs/comm_pipeline_config.json
├── data/reports/sales_report.pdf
├── data/reports/summary_data.xlsx
├── data/incoming_attachments/
├── reports/
├── .env.example
├── .gitignore
└── main.py
```
