# Week 10 — Advanced Spreadsheet Automation & Agentic Workflows

This project demonstrates a config-driven sales report using Python and `openpyxl`.

## Files
- `data/input_data.xlsx`: sample SalesData workbook
- `data/output_report.xlsx`: generated workbook with Audit Log, SalesData, and Raw Data sheets
- `configs/example_spreadsheet_config.json`: task configuration
- `screenshots/`: screenshots of the three requested sheets

## Run
```bash
pip install openpyxl
python generate_report.py
```

Note: sample sales data is based on the supplied Lab handout. The screenshots are generated from this workbook for submission evidence.
